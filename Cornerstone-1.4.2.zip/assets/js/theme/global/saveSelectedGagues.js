import $ from 'jquery';


$("body").on("click", ".addGauge", function() {

	//console.log(window.customizerObject.selectedGauges);

});

$("body").on("click", ".editGauge", function() {

	//console.log(window.customizerObject.selectedGauges);

});


