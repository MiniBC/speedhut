import $ from 'jquery';
import magnific from './magnific';

var CustomizerStepThreeObject = {  //start of step three object

	currentEditIndex: 0,

	saveStyleToSelectedGauge: function() {

		var currentGaugeSelection = $("#pcCanvas").html();
		
		console.log( CustomizerStepThreeObject.currentEditIndex );
		console.log( $("#pcCanvas").html() );
		
		window.customizerObject.selectedGauges[ CustomizerStepThreeObject.currentEditIndex ].dayTimeGaugePreviewLayyer = currentGaugeSelection;


		console.log( window.customizerObject.selectedGauges );

	},
	saveToAllGauges: function() {

		var currentGaugeSelection = $("#pcCanvas").html();

		for(var i = 0; i < window.customizerObject.selectedGauges.length; i++) {

			window.customizerObject.selectedGauges[ i ].dayTimeGaugePreviewLayyer = currentGaugeSelection;

		}

	},
	buildStepThreeGaugePreview: function() {

		var gaugePreviewSection;

		$(".selectedGaugePreivew").html("");

		for(var i = 0; i < window.customizerObject.selectedGauges.length; i++) {

			if(i % 3 == 0) {

				$(".selectedGaugePreivew").append("<br>");
			}

			$(".selectedGaugePreivew").append( "<img class='img-preview' id="+i+" src='https://cdn3.bigcommerce.com/s-ta980ko58k/product_images/uploaded_images/dummy-placeholder.jpg?t=1491341974&_ga=1.163658615.995689909.1490710177'>" );


		}

		console.log( window.customizerObject.selectedGauges );

	},
	setStepThreeGaugePreview: function() {
	
		var gaugeElement;

		var backgroundLayer = $("#pcCanvas").html();

		console.log(backgroundLayer);

		for(var i = 0; i < window.customizerObject.selectedGauges.length; i++) {

			var gaugePreivew = backgroundLayer;
			//var nightGaugePreview = nightBackgroundLayer;

			window.customizerObject.selectedGauges[i].dayTimeGaugePreviewLayyer = "";
			window.customizerObject.selectedGauges[i].dayTimeGaugePreviewLayyer = gaugePreivew;

			// window.customizerObject.selectedGauges[i].nightTimeGaugePreviewLayyer = "";
			// window.customizerObject.selectedGauges[i].nightTimeGaugePreviewLayyer = "";




		}

		CustomizerStepThreeObject.buildStepThreeGaugePreview();
	
	},
	setSettings: function() {

		$("#customizer_layer_2").css("left","0");
		$("#customizer_layer_2").css("top","0");
		
	},
	displayGaugeSpecs: function(index) {

		var gaugespecs = window.customizerObject.selectedGauges[index];
		var gaugeHTML = "";

		$(".gauge-spec-preview").html(""); //clear any html in the section

		for( var i = 0; i < gaugespecs.gaugeAttribute.length; i++ ) {

			var gaugeSpecName = gaugespecs.gaugeAttribute[i].name; 

			if( typeof gaugespecs.gaugeAttribute[i].text === "object" ) {

				var gaugeSpecFeature = gaugespecs.gaugeAttribute[i].text[0]; 

			} else if( typeof gaugespecs.gaugeAttribute[i].text === "string" ) {

				var gaugeSpecFeature = gaugespecs.gaugeAttribute[i].text; 

			}

			gaugeHTML += "<li><b>" + gaugeSpecName + ": </b>" + gaugeSpecFeature + "</li>";

		}

		$(".gauge-spec-preview").append( gaugeHTML );


	}


} //End of step three object

module.exports = function() {

	$(function() {

		window.initstepthree = function() { //called when page loads

			CustomizerStepThreeObject.setSettings();
			CustomizerStepThreeObject.setStepThreeGaugePreview();
			CustomizerStepThreeObject.displayGaugeSpecs(0);

		}

	});

	$("body").on("click", ".img-preview", function() {

		CustomizerStepThreeObject.currentEditIndex = $(this).attr("id");

		$(".img-preview").removeClass("img-preview-select");
		$(this).addClass("img-preview-select");

		window.customizerObject.selectedGauges[ CustomizerStepThreeObject.currentEditIndex ].dayTimeGaugePreviewLayyer;

		$("#pcCanvas").html( window.customizerObject.selectedGauges[ CustomizerStepThreeObject.currentEditIndex ].dayTimeGaugePreviewLayyer );

		CustomizerStepThreeObject.displayGaugeSpecs( CustomizerStepThreeObject.currentEditIndex );

	});

	$("body").on("click", ".apply-to-kit", function() {

		CustomizerStepThreeObject.saveToAllGauges();

		window.customizerObject.updateSelectedGauges();

	});

	$("body").on("click", ".apply-to-gauge", function() {

		CustomizerStepThreeObject.saveStyleToSelectedGauge();
		
		window.customizerObject.updateSelectedGauges();
		

	});

	$("body").on("click", "#daynight", function() {


		//$("#pcCanvas").html( window.customizerObject.selectedGauges[ CustomizerStepThreeObject.currentEditIndex ].dayTimeGaugePreviewLayyer );


		//alert("switch daynight");

	});

	//when day/night is toggled set index to display the correctly selected gauge.


};