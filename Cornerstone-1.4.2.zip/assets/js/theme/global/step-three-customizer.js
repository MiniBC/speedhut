import $ from 'jquery';
import magnific from './magnific';

var CustomizerStepThreeObject = {

}

module.exports = function() {

	$(function(){

		window.initstepthree = function() { //called when page loads

		    $("#customizer_layer_2").css('top', '0');
		    $("#customizer_layer_2").css('left', '0');


		}


	});

};

// daynighticon

//   $( "#daynighticon" ).toggle( "slow", function() {
//     // Animation complete.
//   });